package com.ipss.practicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticasApplicationTests {

	@Test
	void contextLoads() {
	}

}
